<?php
namespace wordpress_code_ai\GA;

use wordpress_code_ai\Abstract_Google_Client;

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class GA_Client extends Abstract_Google_Client {

    const OPTION_JSON        = 'wordpress_code_ai_ga_service_account_json';
    const PROVIDER           = 'ga';
    const OPTION_PROPERTY_ID = 'wordpress_code_ai_ga_default_property_id';
    const TRANSIENT_TOKEN    = 'wordpress_code_ai_ga_token';
    const SCOPE              = 'https://www.googleapis.com/auth/analytics.readonly';
    




    const SCOPE_EDIT         = 'https://www.googleapis.com/auth/analytics.edit';
    const HKDF_INFO          = 'wordpress_code_ai_ga_creds_v1';

    protected static function product_name(): string {
        return 'Google Analytics';
    }

    









    public static function request( string $method, string $url, ?array $body = null, bool $admin_context = false, bool $edit = false ): array {
        $scheme = \wp_parse_url( $url, PHP_URL_SCHEME );
        $host   = \wp_parse_url( $url, PHP_URL_HOST );
        $allowed_hosts = array(
            'oauth2.googleapis.com',
            'analyticsdata.googleapis.com',
            'analyticsadmin.googleapis.com',
        );
        if ( 'https' !== $scheme || ! in_array( $host, $allowed_hosts, true ) ) {
            throw new \RuntimeException( 'GA client: refusing to attach bearer token to non-Google host.' );
        }

        $token = self::get_access_token( $edit ? self::SCOPE_EDIT : '' );

        $args = array(
            'method'              => strtoupper( $method ),
            'headers'             => array(
                'Authorization' => 'Bearer ' . $token,
                'Content-Type'  => 'application/json',
            ),
            'timeout'             => 20,
            
            
            'limit_response_size' => 8388608,
        );
        if ( null !== $body ) {
            $args['body'] = wp_json_encode( $body );
        }

        $response = \wp_remote_request( $url, $args );

        if ( \is_wp_error( $response ) ) {
            throw new \RuntimeException(
                'GA API request failed (transport error): ' . $response->get_error_message() // phpcs:ignore WordPress.Security.EscapeOutput.ExceptionNotEscaped
            );
        }

        $code    = (int) \wp_remote_retrieve_response_code( $response );
        $raw     = \wp_remote_retrieve_body( $response );
        $decoded = json_decode( $raw, true );

        if ( $edit && $code >= 400 ) {
            self::throw_edit_error( $code, $decoded );
        }
        if ( 403 === $code ) {
            if ( $admin_context ) {
                $creds = self::get_credentials();
                throw new \RuntimeException(
                    "Access denied. Add the service account ({$creds['client_email']}) as a Viewer in GA4 → Admin → Property access management, and enable both the Analytics Data API and Analytics Admin API in your Google Cloud project." // phpcs:ignore WordPress.Security.EscapeOutput.ExceptionNotEscaped
                );
            }
            throw new \RuntimeException(
                'Access denied by Google Analytics. The configured service account does not have access to this property. A site administrator can grant access in wordpress-code-ai → Tools → External data → Test connection.'
            );
        }
        if ( 404 === $code ) {
            throw new \RuntimeException(
                'Property not found. Check the numeric property ID (found in GA4 Admin → Property details).'
            );
        }
        if ( 429 === $code ) {
            throw new \RuntimeException(
                'Google Analytics Data API quota exceeded. Core reporting: 1,250 tokens/hour per property. Realtime: 10,000 requests/day per property. Retry after quota reset.'
            );
        }
        if ( $code < 200 || $code >= 300 ) {
            $err = $decoded['error']['message'] ?? "HTTP {$code}";
            throw new \RuntimeException( "GA API error: {$err}" ); // phpcs:ignore WordPress.Security.EscapeOutput.ExceptionNotEscaped
        }

        return is_array( $decoded ) ? $decoded : array();
    }

    








    private static function throw_edit_error( int $code, $decoded ): void {
        $detail = is_array( $decoded ) && isset( $decoded['error']['message'] ) && is_string( $decoded['error']['message'] )
            ? $decoded['error']['message']
            : "HTTP {$code}";
        if ( 401 === $code || 403 === $code ) {
            throw new \RuntimeException(
                "Google Analytics refused the change: {$detail} Changing a property needs the service account to hold the Editor role on it (GA4 → Admin → Property access management); Viewer is enough only for reading." // phpcs:ignore WordPress.Security.EscapeOutput.ExceptionNotEscaped
            );
        }
        if ( 404 === $code ) {
            throw new \RuntimeException(
                "Google Analytics found nothing to change: {$detail} Check the property ID and, for a key event, that it still exists." // phpcs:ignore WordPress.Security.EscapeOutput.ExceptionNotEscaped
            );
        }
        if ( 429 === $code ) {
            throw new \RuntimeException(
                'Google Analytics Admin API quota exceeded. Nothing was changed; retry later.'
            );
        }
        throw new \RuntimeException( "Google Analytics refused the change: {$detail}" ); // phpcs:ignore WordPress.Security.EscapeOutput.ExceptionNotEscaped
    }

    public static function get( string $url, bool $admin_context = false ): array {
        return self::request( 'GET', $url, null, $admin_context );
    }

    public static function post( string $url, array $body, bool $admin_context = false ): array {
        return self::request( 'POST', $url, $body, $admin_context );
    }

    






    public static function edit( string $method, string $url, ?array $body = null ): array {
        return self::request( $method, $url, $body, false, true );
    }

    









    public static function key_events( string $property ): array {
        $events = array();
        $token  = '';
        for ( $page = 0; $page < 10; $page++ ) {
            $url = "https://analyticsadmin.googleapis.com/v1beta/{$property}/keyEvents?pageSize=200";
            if ( '' !== $token ) {
                $url .= '&pageToken=' . rawurlencode( $token );
            }
            $data = self::edit( 'GET', $url );
            foreach ( (array) ( $data['keyEvents'] ?? array() ) as $event ) {
                if ( is_array( $event ) ) {
                    $events[] = $event;
                }
            }
            $token = isset( $data['nextPageToken'] ) && is_string( $data['nextPageToken'] ) ? $data['nextPageToken'] : '';
            if ( '' === $token ) {
                return $events;
            }
        }
        throw new \RuntimeException( 'Google Analytics returned more than ten pages of key events; nothing was changed.' );
    }

    




    public static function default_property_id(): string {
        $id = \wordpress_code_ai\Config::get( self::OPTION_PROPERTY_ID, '' );
        if ( empty( $id ) && in_array( \wordpress_code_ai\Config::constant_name( self::OPTION_PROPERTY_ID ), \wordpress_code_ai\Config_Admin::invalid_settings(), true ) ) {
            
            throw new \RuntimeException(
                'No property_id provided, and WORDPRESS_CODE_AI_GA_DEFAULT_PROPERTY_ID is not a valid GA4 property ID. Set it to the numeric property ID (for example 123456789 or properties/123456789), or pass property_id.'
            );
        }
        if ( empty( $id ) ) {
            throw new \RuntimeException(
                'No property_id provided and no default property configured. Set one in wordpress-code-ai → Tools → External data, or define WORDPRESS_CODE_AI_GA_DEFAULT_PROPERTY_ID in wp-config.php.'
            );
        }
        return self::normalize_property( (string) $id );
    }

    










    public static function write_property( array $arguments ): string {
        if ( ! array_key_exists( 'property_id', $arguments ) || null === $arguments['property_id'] ) {
            
            
            $default = self::default_property_id();
            if ( 1 === preg_match( '#^properties/0+\z#', $default ) ) {
                throw new \RuntimeException( 'The default Google Analytics property is not a GA4 property; set a numeric property ID in wordpress-code-ai → Tools → External data, or pass property_id. Nothing was changed.' );
            }
            return $default;
        }
        $value = $arguments['property_id'];
        if ( is_int( $value ) ) {
            $value = (string) $value;
        }
        $refusal = 'Invalid property_id; expected a numeric GA4 property ID, or omit property_id to use the default property. Nothing was changed.';
        if ( ! is_string( $value ) ) {
            throw new \RuntimeException( $refusal );
        }
        try {
            $property = self::normalize_property( $value );
        } catch ( \RuntimeException $e ) {
            throw new \RuntimeException( $refusal );
        }
        if ( 1 === preg_match( '#^properties/0+\z#', $property ) ) {
            throw new \RuntimeException( $refusal );
        }
        return $property;
    }

    









    public static function normalize_property( string $input ): string {
        $trimmed = trim( $input );
        if ( '' === $trimmed ) {
            throw new \RuntimeException( 'Invalid property_id; expected numeric GA4 property ID.' );
        }
        if ( 'universal' === $trimmed ) {
            return 'properties/0';
        }
        if ( 0 === strpos( $trimmed, 'properties/' ) ) {
            $trimmed = substr( $trimmed, strlen( 'properties/' ) );
        }
        if ( ! preg_match( '/^\d+$/', $trimmed ) ) {
            throw new \RuntimeException( 'Invalid property_id; expected numeric GA4 property ID.' );
        }
        return 'properties/' . $trimmed;
    }

    









    public static function build_date_ranges( array $input ): array {
        if ( empty( $input ) ) {
            throw new \RuntimeException( 'date_ranges is required and must be a non-empty array.' );
        }
        $out = array();
        foreach ( $input as $i => $range ) {
            if ( ! is_array( $range ) ) {
                throw new \RuntimeException( "date_ranges[{$i}] must be an object with start_date and end_date." ); // phpcs:ignore WordPress.Security.EscapeOutput.ExceptionNotEscaped
            }
            foreach ( array( 'start_date', 'end_date' ) as $field ) {
                $value = $range[ $field ] ?? '';
                if ( ! is_string( $value ) || '' === $value ) {
                    throw new \RuntimeException( "date_ranges[{$i}].{$field} is required." ); // phpcs:ignore WordPress.Security.EscapeOutput.ExceptionNotEscaped
                }
                $is_iso   = (bool) preg_match( '/^\d{4}-\d{2}-\d{2}$/', $value );
                $is_magic = in_array( $value, array( 'today', 'yesterday' ), true )
                    || (bool) preg_match( '/^\d+daysAgo$/', $value );
                if ( ! $is_iso && ! $is_magic ) {
                    throw new \RuntimeException( "date_ranges[{$i}].{$field} must be YYYY-MM-DD, NdaysAgo, yesterday, or today." ); // phpcs:ignore WordPress.Security.EscapeOutput.ExceptionNotEscaped
                }
            }
            $entry = array(
                'startDate' => $range['start_date'],
                'endDate'   => $range['end_date'],
            );
            if ( ! empty( $range['name'] ) && is_string( $range['name'] ) ) {
                $entry['name'] = $range['name'];
            }
            $out[] = $entry;
        }
        return $out;
    }
}
